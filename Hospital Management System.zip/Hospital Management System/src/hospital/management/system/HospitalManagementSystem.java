package hospital.management.system;

public class HospitalManagementSystem {

    public static void main(String[] args) {
        //Defines the array limits (Doctors = 3, Patient = 7)
        HospitalStaff[] hospitalStaff = new HospitalStaff[4];
        Doctor[] doctors = new Doctor[3];
        Patient[] patients = new Patient[7];

        //Counters for each type of person
        int hospitalStaffCount = 0;
        int doctorCount = 0;
        int patientCount = 0;

        //The main loop for user input
        while (true) {
        String input = javax.swing.JOptionPane.showInputDialog("Enter: \n 'H' for HospitalStaff \n 'D' for Doctor \n 'P' for Patient \n 'Q' to Quit:");
            
        if (input == null || input.equalsIgnoreCase("Q")) {
        break; // Exit the loop when user chooses to quit
        }
        
        //The switchcase used to choose different options 
        switch (input.toUpperCase()) {
        case "H":
        if (hospitalStaffCount < 4) {
        hospitalStaff[hospitalStaffCount] = new HospitalStaff();
        hospitalStaff[hospitalStaffCount].setPersonDetails();
        hospitalStaffCount++;
        } else {
        javax.swing.JOptionPane.showMessageDialog(null, "Error: You cannot enter more than 4 HospitalStaff.");
        }
        break;

        case "D":
        if (doctorCount < 3) {
        doctors[doctorCount] = new Doctor();
        doctors[doctorCount].setPersonDetails();
        doctorCount++;
        } else {
        javax.swing.JOptionPane.showMessageDialog(null, "Error: You cannot enter more than 3 Doctors.");
        }
        break;

        case "P":
        if (patientCount < 7) {
        patients[patientCount] = new Patient();
        patients[patientCount].setPersonDetails();
        patientCount++;
        } else {
        javax.swing.JOptionPane.showMessageDialog(null, "Error: You cannot enter more than 7 Patients.");
        }
        break;

        default:
        javax.swing.JOptionPane.showMessageDialog(null, "Invalid input. Please enter 'H', 'D', 'P', or 'Q'.");
        break;
        }}

        //Displays the report in the terminal once the program is done running
        System.out.println("\n******* Hospital Management System Report *******");

        //This displays theHospitalStaff details
        System.out.println("Hospital Staff:");
        if (hospitalStaffCount == 0) {
        System.out.println("No Hospital Staff data entered.");
        }else {
        for (int i = 0; i < hospitalStaffCount; i++) {
        hospitalStaff[i].displayPersonDetails();
        }}

        //This displays the Doctor details
        System.out.println("\nDoctors:");
        if (doctorCount == 0) {
        System.out.println("No Doctor data entered.");
        }else {
        for (int i = 0; i < doctorCount; i++) {
        doctors[i].displayPersonDetails();
        }}

        //This displays the Patient details
        System.out.println("\nPatients:");
        if (patientCount == 0) {
        System.out.println("No Patient data entered.");
        }else {
        for (int i = 0; i < patientCount; i++) {
        patients[i].displayPersonDetails();
        }}}}
