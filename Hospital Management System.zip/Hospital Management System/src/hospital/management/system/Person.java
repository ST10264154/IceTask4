package hospital.management.system;

//import
import javax.swing.JOptionPane;

//The data fields for Person
public class Person {
private String firstName;
private String lastName;
private String streetAddress;
private String zipCode;
private String phoneNumber;

//This method sets all the data fields using dialog boxes, the data is saved and appears in the terminal
public void setPersonDetails() {
this.firstName = JOptionPane.showInputDialog("Enter First Name:");
this.lastName = JOptionPane.showInputDialog("Enter Last Name:");
this.streetAddress = JOptionPane.showInputDialog("Enter Street Address:");
this.zipCode = JOptionPane.showInputDialog("Enter Zip Code:");
this.phoneNumber = JOptionPane.showInputDialog("Enter Phone Number:");
}

//Displays all the details on a single command line
public void displayPersonDetails() {
    
//System ouputs details into terminal    
System.out.println("Person Details: " + firstName + " " + lastName + ", " + streetAddress + ", " + zipCode + ", Phone: " + phoneNumber);
}

public static void main(String[] args) {
Person person = new Person();
person.setPersonDetails();
person.displayPersonDetails();
}}

