package hospital.management.system;

//imports
import javax.swing.JOptionPane;
import java.util.ArrayList;
import java.util.List;

//Patient class extends the Person class
public class Patient extends Person {
    
//The additional fields for Patient
private String medicalRecordNumber;
private List<String> ailments;

//Constructor to initialize the ailments list
public Patient() {
ailments = new ArrayList<>();
}

//Method to set all Patient details using dialog boxes, this overrides Person's method 
@Override
public void setPersonDetails() {
    
//Calls the method in Person class to set Person details    
super.setPersonDetails(); 
this.medicalRecordNumber = JOptionPane.showInputDialog("Enter Medical Record Number:");
        
//This Loop is to add ailments to the list
String ailment;
do {
ailment = JOptionPane.showInputDialog("Enter an ailment (leave blank to finish):");
if (!ailment.isEmpty()) {
ailments.add(ailment);
}}
while (!ailment.isEmpty());
}

//Method to display all Patient details, this overrides Person's method
@Override
public void displayPersonDetails() {
    
//Calls the method in Person class to display Person details    
super.displayPersonDetails();

//System ouputs details into terminal
System.out.println("Medical Record Number: " + medicalRecordNumber);
System.out.print("Ailments: ");
if (ailments.isEmpty()) {
System.out.println("None");
}else {
System.out.println(String.join(", ", ailments));
}}

public static void main(String[] args) {
Patient patient = new Patient();
patient.setPersonDetails();
patient.displayPersonDetails();
}}
