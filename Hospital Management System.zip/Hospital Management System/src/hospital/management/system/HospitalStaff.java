package hospital.management.system;

//import
import javax.swing.JOptionPane;

//HospitalStaff class extends the Person class
//The additional fields for HospitalStaff
public class HospitalStaff extends Person {
private String staffID;
private double annualSalary;
private String departmentName;

//Method to set all HospitalStaff details using dialog boxes, this overrides Person's method
@Override
public void setPersonDetails() {
super.setPersonDetails(); // Call the method in Person class to set Person details
this.staffID = JOptionPane.showInputDialog("Enter Staff ID:");
this.annualSalary = Double.parseDouble(JOptionPane.showInputDialog("Enter Annual Salary:"));
this.departmentName = JOptionPane.showInputDialog("Enter Department Name:");
    }

//Method to display all HospitalStaff details, this overrides Person's method
@Override
public void displayPersonDetails() {
    
//Calls the method in Person class to display Person details
super.displayPersonDetails();

//Displays additional HospitalStaff information
//System ouputs details into terminal
System.out.println("Staff ID: " + staffID + ", Annual Salary: R" + annualSalary + ", Department: " + departmentName);
    }

public static void main(String[] args) {
HospitalStaff staff = new HospitalStaff();
staff.setPersonDetails();
staff.displayPersonDetails();
    }}

