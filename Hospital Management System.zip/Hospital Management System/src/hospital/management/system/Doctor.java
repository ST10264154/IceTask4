
package hospital.management.system;

//import
import javax.swing.JOptionPane;

//Doctor class extends the HospitalStaff class
public class Doctor extends HospitalStaff {
    
//This is the additional field for Doctor
private boolean isSpecialist;

//Method to set all Doctor details using dialog boxes (overrides HospitalStaff's method)
@Override
public void setPersonDetails() {
super.setPersonDetails(); // Call the method in HospitalStaff class to set HospitalStaff details
int specialistChoice = JOptionPane.showConfirmDialog(null, 
        
   //Prompt asked, (yes or no option)  
   "Is the doctor a specialist?", 
   "Specialist", JOptionPane.YES_NO_OPTION);

//This converts the choice to boolean
this.isSpecialist = (specialistChoice == JOptionPane.YES_OPTION); 
}

//Method to display all Doctor details, this overrides HospitalStaff's method
@Override
public void displayPersonDetails() {
    
//Calls the method in HospitalStaff class to display HospitalStaff details
super.displayPersonDetails();

//Displays additional Doctor information
System.out.println("Specialist: " + (isSpecialist ? "Yes" : "No"));
}

public static void main(String[] args) {
Doctor doctor = new Doctor();
doctor.setPersonDetails();
doctor.displayPersonDetails();
}}

